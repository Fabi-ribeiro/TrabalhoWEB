como Rodar Localmente seu projeto

1 - Instalar as dependencias do Node JS, rode o comando:

npm install

2- Instalar o Express, rode o comando para que seja criado a pasta node_modules e uma dependencia no arquivo package.json:

npm install express

3- Instalar o Sequelize, rode o comando:

npm install sequelize

4- Instalar dependecias do handlebars:

npm install @handlebars/allow-prototype-access


5- Configure o arquivo databe.js com os dados do banco criado no postgrees 

6- Apos, rode o projeto com o comando:

npm start
