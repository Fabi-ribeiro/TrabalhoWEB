const sequelize = require('../config/database');
const Usuario = require('./usuario')(sequelize);
const Sala = require('./sala')(sequelize);
const Item = require('./item')(sequelize);
const Reserva = require('./reserva')(sequelize);
const ItensReserva = require('./itensReserva')(sequelize);
const Historico = require('./historico')(sequelize);
const Avaliacao = require('./avaliacao')(sequelize);

// associações
Usuario.hasMany(Reserva, { foreignKey: 'id_usuario' });
Reserva.belongsTo(Usuario, { foreignKey: 'id_usuario' });

Sala.hasMany(Reserva, { foreignKey: 'id_sala' });
Reserva.belongsTo(Sala, { foreignKey: 'id_sala' });

Item.belongsToMany(Reserva, { through: ItensReserva, foreignKey: 'id_item', otherKey: 'id_reserva' });
Reserva.belongsToMany(Item, { through: ItensReserva, foreignKey: 'id_reserva', otherKey: 'id_item' });

// Associação direta para reservas de um único item
Reserva.belongsTo(Item, { foreignKey: 'id_item' });
Item.hasMany(Reserva, { foreignKey: 'id_item' });


Reserva.hasMany(Historico, { foreignKey: 'id_reserva' });
Historico.belongsTo(Reserva, { foreignKey: 'id_reserva' });

Usuario.hasMany(Historico, { foreignKey: 'id_usuario_actor' });
Historico.belongsTo(Usuario, { foreignKey: 'id_usuario_actor' });

Reserva.hasMany(Avaliacao, { foreignKey: 'id_reserva' });
Avaliacao.belongsTo(Reserva, { foreignKey: 'id_reserva' });

Usuario.hasMany(Avaliacao, { foreignKey: 'id_usuario' });
Avaliacao.belongsTo(Usuario, { foreignKey: 'id_usuario' });

module.exports = { sequelize, Usuario, Sala, Item, Reserva, ItensReserva, Historico, Avaliacao };
