const { DataTypes } = require('sequelize');
module.exports = (sequelize) => {
  const Sala = sequelize.define('Sala', {
    id: { type: DataTypes.INTEGER, primaryKey:true, autoIncrement:true },
    nome_sala: { type: DataTypes.STRING, allowNull:false },
    capacidade: { type: DataTypes.INTEGER, allowNull:false },
    localizacao: { type: DataTypes.STRING, allowNull:true },
    imagem: { type: DataTypes.TEXT, allowNull:true },
  }, { tableName: 'salas' });
  return Sala;
};
