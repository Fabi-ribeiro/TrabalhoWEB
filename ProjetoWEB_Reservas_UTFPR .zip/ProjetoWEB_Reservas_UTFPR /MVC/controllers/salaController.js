const { Sala, Reserva } = require('../models');
const { Sequelize } = require('sequelize');
const { Op } = Sequelize;

module.exports = {
  // Listar salas (admin)
  listar: async (req, res) => {
    try {
      const salas = await Sala.findAll();
      res.render('salas/list', { salas });
    } catch (error) {
      console.error('Erro ao listar salas:', error);
      res.status(500).send('Erro ao listar salas.');
    }
  },

  // Formulário de criação
  createForm: (req, res) => {
    res.render('salas/create');
  },

  // Criar nova sala
  create: async (req, res) => {
    try {
      const { nome_sala, capacidade, descricao } = req.body;

      await Sala.create({ nome_sala, capacidade, descricao });

      req.session.flash = {
        tipo: 'success',
        mensagem: 'Sala criada com sucesso!'
      };

      res.redirect('/salas/list');
    } catch (error) {
      console.error('Erro ao criar sala:', error);
      res.render('salas/create', {
        error: 'Erro ao criar sala. Tente novamente.'
      });
    }
  },

  // Formulário de edição
  editForm: async (req, res) => {
    try {
      const sala = await Sala.findByPk(req.params.id);
      if (!sala) return res.status(404).send('Sala não encontrada');

      res.render('salas/edit', { sala });
    } catch (error) {
      console.error('Erro ao carregar sala:', error);
      res.status(500).send('Erro interno.');
    }
  },

  // Atualizar sala
  update: async (req, res) => {
    try {
      const sala = await Sala.findByPk(req.params.id);
      if (!sala) return res.status(404).send('Sala não encontrada');

      const { nome_sala, capacidade, descricao } = req.body;

      sala.nome_sala = nome_sala;
      sala.capacidade = capacidade;
      sala.descricao = descricao;

      await sala.save();

      req.session.flash = {
        tipo: 'success',
        mensagem: 'Sala atualizada com sucesso!'
      };

      res.redirect('/salas/list');
    } catch (error) {
      console.error('Erro ao atualizar sala:', error);
      res.status(500).send('Erro ao atualizar sala.');
    }
  },

  // Excluir sala
  delete: async (req, res) => {
    try {
      const sala = await Sala.findByPk(req.params.id);
      if (!sala) return res.status(404).send('Sala não encontrada');

      await sala.destroy();

      req.session.flash = {
        tipo: 'success',
        mensagem: 'Sala excluída com sucesso!'
      };

      res.redirect('/salas/list');
    } catch (error) {
      console.error('Erro ao excluir sala:', error);
      res.status(500).send('Erro ao excluir sala.');
    }
  },

  // Página de reserva da sala
  reservarPage: async (req, res) => {
    try {
      const sala = await Sala.findByPk(req.params.id);
      const usuario = req.session.usuario;

      if (!sala) return res.status(404).send('Sala não encontrada');

      res.render('reservas/create', {
        sala,
        usuario
      });
    } catch (error) {
      console.error('Erro ao carregar página de reserva:', error);
      res.status(500).send("Erro ao carregar página de reserva.");
    }
  },

  // Criar reserva da sala
  reservar: async (req, res) => {
    try {
      const usuario = req.session.usuario;
      if (!usuario) return res.redirect('/login');

      const salaId = req.params.id;
      const { data_reserva, hora_inicio, hora_fim, finalidade, observacoes } = req.body;

      if (!data_reserva || !hora_inicio || !hora_fim || !finalidade) {
        return res.render('reservas/create', {
          sala: await Sala.findByPk(salaId),
          usuario,
          error: 'Preencha todos os campos obrigatórios.'
        });
      }

      // Validação de horários
      if (hora_inicio < '07:30' || hora_fim > '23:00') {
        return res.render('reservas/create', {
          sala: await Sala.findByPk(salaId),
          usuario,
          error: 'Horário permitido apenas entre 07:30 e 23:00.'
        });
      }

      // Verifica conflitos
      const conflito = await Reserva.findOne({
        where: {
          id_sala: salaId,
          status: 'CONFIRMADA',
          data_reserva,
          [Op.and]: [
            { hora_inicio: { [Op.lt]: hora_fim } },
            { hora_fim: { [Op.gt]: hora_inicio } }
          ]
        }
      });

      if (conflito) {
        return res.render('reservas/create', {
          sala: await Sala.findByPk(salaId),
          usuario,
          error: 'Já existe uma reserva nesse horário para esta sala.'
        });
      }

      // Criar reserva
      await Reserva.create({
        id_sala: salaId,
        id_usuario: usuario.id,
        data_reserva,
        hora_inicio,
        hora_fim,
        finalidade,
        observacoes,
        status: 'CONFIRMADA'
      });

      req.session.flash = {
        tipo: 'success',
        mensagem: 'Reserva de sala realizada com sucesso!'
      };

      return res.redirect('/home'); 
    } catch (error) {
      console.error('Erro ao reservar sala:', error);

      req.session.flash = {
        tipo: 'error',
        mensagem: 'Erro ao reservar sala.'
      };

      return res.redirect('/home');
    }
  }
};
