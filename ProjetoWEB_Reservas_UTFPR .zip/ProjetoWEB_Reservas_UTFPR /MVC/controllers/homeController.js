const { Sala, Item } = require('../models');

module.exports = {
  home: async (req, res) => {
    try {
      const usuario = req.session.usuario;

      // Busca salas e itens
      const salas = await Sala.findAll({ raw: true });
      const itens = await Item.findAll({ raw: true });

      // Combina ambos em um único array
      const recursos = [
        ...salas.map(s => ({ ...s, tipo: 'Sala' })),
        ...itens.map(i => ({ ...i, tipo: 'Item' }))
      ];

      // Renderiza a view
      res.render('home/home', {
        usuario,
        recursos,
        isAdmin: usuario && usuario.tipo_usuario === 'ADMIN'
      });
    } catch (error) {
      console.error('Erro ao carregar home:', error);
      res.status(500).send('Erro ao carregar a página inicial.');
    }
  }
};
