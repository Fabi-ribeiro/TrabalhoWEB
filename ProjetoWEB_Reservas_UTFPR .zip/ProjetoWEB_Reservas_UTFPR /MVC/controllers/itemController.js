const { Item } = require('../models');

module.exports = class itemController {
  // LISTAR 
  static async listar(req, res) {
    try {
      const itens = await Item.findAll({ raw: true });
      const usuario = req.session.usuario;

      console.log("📦 Itens encontrados:", itens.length);

      res.render("itens/list", {
        layout: 'main',
        itens,
        usuario,
        isAdmin: usuario &&
          (usuario.tipo_usuario === "ADMIN" || usuario.tipo_usuario === "ADM")
      });
    } catch (error) {
      console.error("Erro ao listar itens:", error);
      res.status(500).send("Erro ao listar itens: " + error.message);
    }
  }

  // FORMULÁRIO DE CRIAÇÃO 
  static async createForm(req, res) {
    const usuario = req.session.usuario;
    if (!usuario ||
      (usuario.tipo_usuario !== 'ADMIN' && usuario.tipo_usuario !== 'ADM')) {
      return res.redirect('/itens');
    }

    res.render('itens/create', {
      layout: 'main',
      usuario,
      isAdmin: true
    });
  }

  // CRIAR ITEM 
  static async createItem(req, res) {
    try {
      const { nome_item, categoria, quantidade_total, local, imagem } = req.body;

      // para avaliação não ser preenchida manualmente
      await Item.create({
        nome_item,
        categoria,
        quantidade_total,
        local,
        imagem,
        avaliacao: null
      });

      console.log("Novo item criado:", nome_item);
      res.redirect('/itens');
    } catch (err) {
      console.error("Erro ao criar item:", err);
      res.status(500).send('Erro ao criar item.');
    }
  }

  // FORMULÁRIO DE EDIÇÃO 
  static async editForm(req, res) {
    try {
      const id = req.params.id;
      const item = await Item.findByPk(id, { raw: true });
      if (!item) {
        return res.status(404).send('Item não encontrado');
      }

      res.render('itens/edit', {
        layout: 'main',
        item,
        usuario: req.session.usuario
      });
    } catch (error) {
      console.error('❌ Erro ao carregar formulário de edição de item:', error);
      res.status(500).send('Erro ao carregar edição de item.');
    }
  }


  // ATUALIZAR ITEM 
  static async updateItem(req, res) {
    try {
      const id = req.params.id;
      const { nome_item, categoria, quantidade_total, local, imagem } = req.body;

      await Item.update(
        { nome_item, categoria, quantidade_total, local, imagem },
        { where: { id } }
      );

      console.log("Item atualizado:", nome_item);
      res.redirect('/home');
    } catch (error) {
      console.error("Erro ao atualizar item:", error);
      res.status(500).send('Erro ao atualizar item.');
    }
  }

  // EXCLUIR ITEM 
  static async deleteItem(req, res) {
    const usuario = req.session.usuario;
    if (!usuario ||
      (usuario.tipo_usuario !== 'ADMIN' && usuario.tipo_usuario !== 'ADM')) {
      return res.redirect('/home');
    }

    const id = req.params.id;
    await Item.destroy({ where: { id } });
    console.log("🗑️ Item removido ID:", id);
    res.redirect('/home');
  }
};
