const { Avaliacao, Reserva } = require('../models');
module.exports = {
  list: async (req,res) => {
    const avaliacoes = await Avaliacao.findAll({ include: [Reserva] });
    res.render('avaliacoes/list', { avaliacoes });
  },
  createForm: async (req,res) => {
    const reservas = await Reserva.findAll({ where: { id_usuario: req.session.usuario.id }});
    res.render('avaliacoes/create', { reservas });
  },
  create: async (req,res) => {
    const { id_reserva, nota, comentario } = req.body;
    await Avaliacao.create({ id_reserva, id_usuario: req.session.usuario.id, nota, comentario });
    res.redirect('/avaliacoes/list');
  }
};
