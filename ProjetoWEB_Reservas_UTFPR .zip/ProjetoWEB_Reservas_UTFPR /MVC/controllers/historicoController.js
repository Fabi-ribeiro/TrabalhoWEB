const { Reserva, Sala, Item } = require('../models');
const { Op } = require('sequelize');

module.exports = {
  async listarHistorico(req, res) {
    try {
      const userId = req.session.usuario.id;

      const reservas = await Reserva.findAll({
        where: { id_usuario: userId },
        include: [
          { model: Sala, attributes: ['nome_sala'] },
          { model: Item, attributes: ['nome_item'] }
        ],
        order: [['data_reserva', 'DESC']]
      });

      res.render('historico/list', { reservas });
    } catch (error) {
      console.log(error);
      res.status(500).send('Erro ao carregar histórico');
    }
  }
};
