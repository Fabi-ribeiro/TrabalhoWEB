const { Sequelize } = require('sequelize');
const { Reserva, Sala, Item, ItensReserva, Historico } = require('../models');
const { Op } = Sequelize;

const HORA_MIN = '07:30';
const HORA_MAX = '23:00';

function timeToSeconds(h) {
  const parts = h.split(':').map(Number);
  return parts[0] * 3600 + parts[1] * 60 + (parts[2] || 0);
}

module.exports = {
  // Listagem de reservas do usuário (ou admin)
  list: async (req, res) => {
    try {
      const usuario = req.session.usuario;

      const hoje = new Date().toISOString().split("T")[0]; // padrao yyyy-mm-dd

      let where = {
        data_reserva: { [Op.gte]: hoje }  // apenas reservas atuais ou futuras
      };

      if (usuario?.tipo_usuario !== 'ADMIN') {
        where.id_usuario = usuario.id;  // usuário comum ver somente as dele
      }

      const reservas = await Reserva.findAll({
        where,
        include: [Sala, Item],
        order: [
          ['data_reserva', 'ASC'],
          ['hora_inicio', 'ASC']
        ]
      });

      res.render('reservas/list', { reservas, usuario });
    } catch (error) {
      console.error('Erro ao listar reservas:', error);
      res.status(500).send('Erro ao listar reservas.');
    }
  },

  create: async (req, res) => {
    try {
      const usuario = req.session.usuario;
      const { data_reserva, hora_inicio, hora_fim, id_sala } = req.body;

      if (!data_reserva || !hora_inicio || !hora_fim || !id_sala) {
        return res.render('reservas/create', { error: 'Preencha todos os campos obrigatórios.' });
      }

      await Reserva.create({
        id_usuario: usuario.id,
        id_sala,
        data_reserva,
        hora_inicio,
        hora_fim,
        status: 'CONFIRMADA'
      });

      return res.redirect('/reservas/list');
    } catch (err) {
      console.error('Erro ao criar reserva genérica:', err);
      return res.render('reservas/create', { error: 'Erro ao criar reserva.' });
    }
  },

  // Formulário geral de reserva
  createPage: async (req, res) => {
    const salas = await Sala.findAll();
    const itens = await Item.findAll();
    res.render('reservas/create', { salas, itens });
  },

  // Formulário de reserva de um item específico
  createFromItemPage: async (req, res) => {
    try {
      const item = await Item.findByPk(req.params.id, { raw: true });
      if (!item) return res.status(404).send('Item não encontrado');
      const usuario = req.session.usuario;
      res.render('reservas/create', { layout: 'main', item, usuario });
    } catch (error) {
      console.error('Erro ao carregar formulário de reserva:', error);
      res.status(500).send('Erro ao carregar formulário de reserva.');
    }
  },

  // Criação da reserva de item
  createFromItem: async (req, res) => {
    try {
      const usuario = req.session.usuario;
      if (!usuario) return res.redirect('/login');

      const { item_id, data_inicio, data_fim, hora_inicio, hora_fim, finalidade, observacoes } = req.body;

      if (!data_inicio || !hora_inicio || !hora_fim || !finalidade) {
        return res.render('reservas/create', {
          layout: 'main',
          error: '⚠️ Preencha todos os campos obrigatórios.',
          item: await Item.findByPk(item_id, { raw: true }),
          usuario
        });
      }

      const item = await Item.findByPk(item_id);
      if (!item) {
        return res.render('reservas/create', {
          layout: 'main',
          error: 'Item não encontrado.',
          usuario
        });
      }

      if (hora_inicio < HORA_MIN || hora_fim > HORA_MAX) {
        return res.render('reservas/create', {
          layout: 'main',
          item,
          error: `Horário permitido apenas entre ${HORA_MIN} e ${HORA_MAX}.`,
          usuario
        });
      }

      const conflito = await Reserva.findOne({
        where: {
          id_item: item_id,
          status: 'CONFIRMADA',
          data_reserva: data_inicio,
          [Op.and]: [
            { hora_inicio: { [Op.lt]: hora_fim } },
            { hora_fim: { [Op.gt]: hora_inicio } }
          ]
        }
      });

      if (conflito) {
        return res.render('reservas/create', {
          layout: 'main',
          item,
          error: '⛔ Já existe uma reserva neste horário para este item.',
          usuario
        });
      }

      // Criação da reserva
      await Reserva.create({
        id_item: item.id,
        id_usuario: usuario.id,
        data_reserva: data_inicio,
        hora_inicio,
        hora_fim,
        finalidade,
        observacoes,
        status: 'CONFIRMADA'
      });

      req.session.flash = {
        tipo: 'success',
        mensagem: '✅ Reserva confirmada com sucesso!'
      };

      return res.redirect('/home');
    } catch (error) {
      console.error('Erro ao criar reserva do item:', error);
      req.session.flash = {
        tipo: 'error',
        mensagem: '❌ Ocorreu um erro ao confirmar a reserva.'
      };
      return res.redirect('/home');
    }
  },

  // Confirmar (apenas admin) -- REVISAR COM OS MENINOS
  confirmar: async (req, res) => {
    try {
      const usuario = req.session.usuario;
      if (!usuario || usuario.tipo_usuario !== 'ADMIN') return res.status(403).send('Somente ADMIN');
      const reserva = await Reserva.findByPk(req.params.id);
      if (!reserva) return res.redirect('/reservas/list');
      reserva.status = 'CONFIRMADA';
      await reserva.save();
      await Historico.create({
        id_reserva: reserva.id,
        acao: 'CONFIRMAR',
        detalhe: `Confirmada por ${usuario.nome}`,
        id_usuario_actor: usuario.id
      });
      return res.redirect('/reservas/list');
    } catch (err) {
      console.error(err);
      return res.redirect('/reservas/list');
    }
  },

  // Cancelar reserva
  cancelar: async (req, res) => {
    try {
      const usuario = req.session.usuario;
      const reserva = await Reserva.findByPk(req.params.id);
      if (!reserva) return res.redirect('/reservas/list');
      if (reserva.id_usuario !== usuario.id && usuario.tipo_usuario !== 'ADMIN')
        return res.status(403).send('Acesso negado');
      reserva.status = 'CANCELADA';
      await reserva.save();
      await Historico.create({
        id_reserva: reserva.id,
        acao: 'CANCELAR',
        detalhe: `Cancelada por ${usuario.nome}`,
        id_usuario_actor: usuario.id
      });
      return res.redirect('/reservas/list');
    } catch (err) {
      console.error(err);
      return res.redirect('/reservas/list');
    }
  },

  // Criar reserva de uma sala
  createFromSala: async (req, res) => {
    try {
      const usuario = req.session.usuario;
      if (!usuario) return res.redirect('/login');

      const { sala_id, data_reserva, hora_inicio, hora_fim, finalidade, observacoes } = req.body;

      if (!data_reserva || !hora_inicio || !hora_fim || !finalidade) {
        return res.render('reservas/create', {
          error: 'Preencha todos os campos obrigatórios.'
        });
      }

      // Verifica conflito
      const conflito = await Reserva.findOne({
        where: {
          id_sala: sala_id,
          status: 'CONFIRMADA',
          data_reserva,
          [Op.and]: [
            { hora_inicio: { [Op.lt]: hora_fim } },
            { hora_fim: { [Op.gt]: hora_inicio } }
          ]
        }
      });

      if (conflito) {
        return res.render('reservas/create', {
          error: 'Já existe uma reserva nesse horário para esta sala.'
        });
      }

      // Cria reserva
      await Reserva.create({
        id_sala: sala_id,
        id_usuario: usuario.id,
        data_reserva,
        hora_inicio,
        hora_fim,
        finalidade,
        observacoes,
        status: 'CONFIRMADA'
      });

      req.session.flash = {
        tipo: 'success',
        mensagem: '✅ Reserva de sala confirmada com sucesso!'
      };

      return res.redirect('/home');   
    } catch (error) {
      console.error('Erro ao criar reserva da sala:', error);

      req.session.flash = {
        tipo: 'error',
        mensagem: '❌ Ocorreu um erro ao confirmar a reserva da sala.'
      };

      return res.redirect('/home');  
    }
  },

  reservarPage: async (req, res) => {
    try {
      const sala = await Sala.findByPk(req.params.id, { raw: true });
      if (!sala) return res.status(404).send("Sala não encontrada");

      const usuario = req.session.usuario;

      res.render("reservas/create", {
        sala,
        usuario,
        layout: "main"
      });
    } catch (err) {
      console.error("Erro ao carregar página de reserva da sala:", err);
      res.status(500).send("Erro interno.");
    }
  },
};

