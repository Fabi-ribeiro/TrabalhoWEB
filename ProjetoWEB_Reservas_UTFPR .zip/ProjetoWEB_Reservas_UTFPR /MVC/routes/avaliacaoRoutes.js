const express = require('express');
const router = express.Router();
const avaliacaoController = require('../controllers/avaliacaoController');
const { isAuthenticated } = require('../middlewares/auth');

router.get('/list', isAuthenticated, avaliacaoController.list);
router.get('/create', isAuthenticated, avaliacaoController.createForm);
router.post('/create', isAuthenticated, avaliacaoController.create);

module.exports = router;
