const express = require('express');
const router = express.Router();
const reservaController = require('../controllers/reservaController');
const { isAuthenticated, isAdmin } = require('../middlewares/auth');

// Listagem geral de reservas
router.get('/list', isAuthenticated, reservaController.list);

// Criar reserva de item comum
router.get('/create', isAuthenticated, reservaController.createPage);
router.post('/create', isAuthenticated, reservaController.create);

// Criar reserva a partir de um item (clicado na home)
router.get('/item/:id', isAuthenticated, reservaController.createFromItemPage);
router.post('/item', isAuthenticated, reservaController.createFromItem);

// Criar reserva a partir de uma sala
router.post('/sala', isAuthenticated, reservaController.createFromSala);

// Ações administrativas
router.get('/confirmar/:id', isAuthenticated, isAdmin, reservaController.confirmar);
router.get('/cancelar/:id', isAuthenticated, reservaController.cancelar);

module.exports = router;
