const express = require('express');
const router = express.Router();
const salaController = require('../controllers/salaController');
const { isAuthenticated, isAdmin } = require('../middlewares/auth');

// Listagem de salas (usada no painel de administração, se quiser)
router.get('/list', isAuthenticated, salaController.listar);

// Criar nova sala
router.get('/create', isAuthenticated, isAdmin, salaController.createForm);
router.post('/create', isAuthenticated, isAdmin, salaController.create);

// Editar e atualizar sala
router.get('/edit/:id', isAuthenticated, isAdmin, salaController.editForm);  // mostra o formulário
router.post('/update/:id', isAuthenticated, isAdmin, salaController.update); // salva as alterações

// Excluir sala
router.post('/delete/:id', isAuthenticated, isAdmin, salaController.delete);

// Reservar sala (usuário comum)
router.get('/reservar/:id', isAuthenticated, salaController.reservarPage);
router.post('/reservar/:id', isAuthenticated, salaController.reservar);

module.exports = router;
