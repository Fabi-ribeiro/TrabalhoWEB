const express = require('express');
const session = require('express-session');
const path = require('path');
const { engine } = require('express-handlebars');
const Handlebars = require('handlebars');
const { allowInsecurePrototypeAccess } = require('@handlebars/allow-prototype-access');
const sequelize = require('./config/database');
const { Item, Sala } = require('./models');

// Rotas
const authRoutes = require('./routes/authRoutes');
const usuarioRoutes = require('./routes/usuarioRoutes');
const salaRoutes = require('./routes/salaRoutes');
const itemRoutes = require('./routes/itemRoutes');
const reservaRoutes = require('./routes/reservaRoutes');
const historicoRoutes = require('./routes/historicoRoutes');
const avaliacaoRoutes = require('./routes/avaliacaoRoutes');
const perfilRoutes = require('./routes/perfilRoutes');

const app = express();

// HANDLEBARS CONFIG 
app.engine('handlebars', engine({
  handlebars: allowInsecurePrototypeAccess(Handlebars),
  defaultLayout: 'main',
  layoutsDir: path.join(__dirname, 'views', 'layouts'),
  partialsDir: path.join(__dirname, 'views', 'partials'),
  helpers: {
    ifEquals: function (a, b, opts) {
      return a === b ? opts.fn(this) : opts.inverse(this);
    },
    eq: (a, b) => a === b,
    or: (a, b) => a || b,
    formatDate: (date) => {
      if (!date) return '';
      return new Date(date).toLocaleDateString('pt-BR');
    },
    formatTime: (time) => {
      if (!time) return '';
      return time.slice(0, 5);
    }
  }
}));

app.set('view engine', 'handlebars');
app.set('views', path.join(__dirname, 'views'));

// MIDDLEWARES 
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use(
  session({
    secret: 'reservasutfpr_secret',
    resave: false,
    saveUninitialized: false
  })
);

// Disponibiliza usuário nas views automaticamente
app.use((req, res, next) => {
  res.locals.usuario = req.session.usuario || null;
  next();
});

// ROTAS ORDEM

// ROTAS DE AUTENTICAÇÃO SEMPRE PRIMEIRO
app.use('/', authRoutes);

// Depois rotas de cadastro/login de usuários
app.use('/usuarios', usuarioRoutes);

// Página inicial (home unificada)
app.get(['/home', '/'], async (req, res) => {
  try {
    const usuario = req.session.usuario;
    if (!usuario) return res.redirect('/login');

    const salas = await Sala.findAll({ raw: true });
    const itens = await Item.findAll({ raw: true });

    const recursos = [
      ...salas.map(s => ({ ...s, tipo: 'Sala' })),
      ...itens.map(i => ({ ...i, tipo: 'Item' }))
    ];

    res.render('home/home', {
      layout: 'main',
      usuario,
      recursos,
      isAdmin: usuario && usuario.tipo_usuario === 'ADMIN'
    });
  } catch (error) {
    console.error('Erro ao carregar home:', error);
    res.status(500).send('Erro ao carregar página inicial.');
  }
});

// Demais rotas
app.use('/salas', salaRoutes);
app.use('/itens', itemRoutes);
app.use('/reservas', reservaRoutes);
app.use('/historico', historicoRoutes);
app.use('/avaliacoes', avaliacaoRoutes);
app.use('/perfil', perfilRoutes);

// BANCO E SERVIDOR
sequelize
  .sync({ alter: true })
  .then(() => {
    console.log('✅ Banco sincronizado com sucesso!');
    const PORT = process.env.PORT || 3000;
    app.listen(PORT, () =>
      console.log(`🚀 Servidor rodando: http://localhost:${PORT}`)
    );
  })
  .catch(err => console.error('❌ Erro ao sincronizar banco:', err));
