const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('Nome_seu_banco_de_dados', 'usuario', 'senha', {
  host: 'localhost',
  dialect: 'postgres',
  logging: false
});

module.exports = sequelize;
